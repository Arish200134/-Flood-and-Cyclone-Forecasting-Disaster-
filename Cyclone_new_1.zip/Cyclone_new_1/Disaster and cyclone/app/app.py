from flask import Flask, render_template, abort,request,redirect,url_for,flash
import catboost
from catboost import CatBoostClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import pandas as pd
from sklearn.preprocessing import StandardScaler
import joblib
import numpy as np
import pandas as pd
import pickle # saving and loading trained model
from os import path
# importing library for plotting
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split 
import tensorflow as tf
from tensorflow.keras.utils import to_categorical
from keras.layers import Dense, Convolution1D,LSTM,MaxPooling1D, MaxPool1D, Flatten, Dropout # importing dense layer
from keras.models import Sequential #importing Sequential layer
from keras.layers import Input
from keras.models import Model
from keras.models import load_model


modelflood = CatBoostClassifier()
modelflood.load_model('catboost_flood.cbm')
app = Flask(__name__)
scalerflood = joblib.load('standard_scaler.joblib')
scalerCyclone = joblib.load('scaler.pkl')

modelcyclone = load_model("CNNLSTM.h5")
print(modelcyclone.summary())
app.secret_key='5791628bb0b13ce0c676dfde280ba245' 
cyclone=['Disturbance (of any intensity)', 'Subtropical cyclone' ,'Extratropical cyclone (of any intensity)' ,'Tropical cyclone of hurricane intensity (> 64 knots)' ,'A low that is neither a tropical cyclone, a subtropical cyclone, nor an extratropical cyclone (of any intensity)' ,'Tropical cyclone of tropical depression intensity (< 34 knots)', 'Tropical cyclone of tropical storm intensity (34-63 knots)']

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/refreshFlood')
def refreshFlood():
   
    return redirect(url_for('floodHome'))
@app.route('/about')
def about_team():
    return render_template('about-team.html')

@app.route('/contacts')
def contact():
    return render_template('contact.html')

@app.route('/services')
def service():
    return render_template('service.html')


@app.route('/floodHome')
def floodHome():
   
    return render_template('flood_entry.html',result=[])

@app.route('/floodResult',methods=['POST', 'GET'])
def floodResult():
        try:
            diseaster=request.form['SEL']
            inputfile = request.files['inputfile']
            inputfile.save("input.csv")
            df = pd.read_csv('input.csv')
            result=[diseaster,0,0]
            result[2]=df.values.tolist()
            result.append(df.columns)
            if(diseaster=="Flood"):
                
                X_scaled = scalerflood.fit_transform(df)
                y_pred = modelflood.predict(X_scaled)
                print(y_pred)
                if int(y_pred[0]) == 1:
                    result[1]="Yes"
                else:
                    result[1]="No"

            else:
                X=np.array(df)
                X = scalerCyclone.transform(X)
                X_data=np.array(X)
                X_test = np.reshape(X_data, ( X_data.shape[0], X_data.shape[1], 1))
                predict=modelcyclone.predict(X_test)
                y_pred=np.argmax(predict, axis=1)
                print(y_pred)
                result[1]=cyclone[y_pred[0]]
            return render_template('flood_result.html',result=result)
        except:
            return redirect(url_for('floodHome'))



if __name__ == '__main__':
    app.run(debug = True)